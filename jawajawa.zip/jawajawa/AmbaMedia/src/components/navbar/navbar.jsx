import React from 'react';

function Navbar() {
  const categories = [
    { name: "Business", path: "/business" },
    { name: "Entertainment", path: "/entertainment" },
    { name: "General", path: "/general" },
    { name: "Health", path: "/health" },
    { name: "Science", path: "/science" },
    { name: "Sports", path: "/sports" },
    { name: "Technology", path: "/technology" },
  ];

  return (
    <nav className="header">
      <div className="logo">
        <h4>Amba Media</h4>
        <small>NewsApp</small>
      </div>

      <ul className="category-list">
        {categories.map((category) => (
          <li key={category.name} className="category-item">
            <a href={category.path}>{category.name}</a>
          </li>
        ))}
      </ul>

      <div className="search-bar">
        <form>
          <input
            type="text"
            name="search"
            placeholder="Search news..."
            aria-label="Search news"
          />
          <button type="submit">Search</button>
        </form>
      </div>
    </nav>
  );
}

export default Navbar;